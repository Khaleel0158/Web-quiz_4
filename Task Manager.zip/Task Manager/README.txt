Task Manager Application

Setup Instructions

Backend
1. Navigate to the `backend` folder.
2. Install dependencies: 

`npm init -y
npm install express mongoose bcryptjs jsonwebtoken nodemailer dotenv cors
npm install --save-dev nodemon`.

3. Create a `.env` file with the following variables:

MONGO_URI=<your_mongodb_uri>
JWT_SECRET=<your_jwt_secret>
EMAIL_USER=<your_email>
EMAIL_PASS=<your_email_password>

4. Start the server: `npm start`.

Frontend
1. Navigate to the `frontend` folder.
2. Install dependencies: 

`npm init -y
npx create-react-app task-manager-frontend
cd task-manager-frontend
npm install axios react-router-dom`

3. Start the development server: `npm start`.

Access the App
- Open `http://localhost:3000` in your browser.