import React, { useState, useEffect } from 'react';
import axios from 'axios';

const TaskList = () => {
  const [tasks, setTasks] = useState([]);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [filters, setFilters] = useState({});

  // Fetch tasks from the backend
  useEffect(() => {
    fetchTasks();
  }, [filters]);

  const fetchTasks = async () => {
    try {
      const { data } = await axios.get('/api/tasks', { params: filters });
      setTasks(data);
    } catch (err) {
      console.error(err);
    }
  };

  // Handle task creation
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('/api/tasks', { title, description });
      setTasks([...tasks, response.data]); // Add new task to the list
      setTitle(''); // Reset form fields
      setDescription('');
    } catch (err) {
      console.error('Error creating task:', err.response?.data || err.message);
      alert('Failed to create task.');
    }
  };

  // Handle task deletion
  const handleDelete = async (id) => {
    try {
      await axios.delete(`/api/tasks/${id}`);
      setTasks(tasks.filter((task) => task._id !== id)); // Remove task from the list
    } catch (err) {
      console.error(err);
    }
  };

  // Handle filter changes
  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters({ ...filters, [name]: value });
  };

  return (
    <div>
      {/* Task Form */}
      <form onSubmit={handleSubmit}>
        <h2>Create Task</h2>
        <input
          type="text"
          placeholder="Title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          required
        />
        <textarea
          placeholder="Description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          required
        />
        <button type="submit">Create Task</button>
      </form>

      {/* Filters */}
      <div>
        <h3>Filters</h3>
        <input
          type="text"
          name="search"
          placeholder="Search tasks"
          onChange={handleFilterChange}
        />
        <select name="priority" onChange={handleFilterChange}>
          <option value="">All Priorities</option>
          <option value="low">Low</option>
          <option value="medium">Medium</option>
          <option value="high">High</option>
        </select>
      </div>

      {/* Task List */}
      <div>
        <h2>Tasks</h2>
        <ul>
          {tasks.map((task) => (
            <li key={task._id}>
              <strong>{task.title}</strong>: {task.description}
              <button onClick={() => handleDelete(task._id)}>Delete</button>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default TaskList;