import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useParams, useNavigate } from 'react-router-dom';

const TaskDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [task, setTask] = useState(null);

  useEffect(() => {
    fetchTask();
  }, []);

  const fetchTask = async () => {
    try {
      const { data } = await axios.get(`/api/tasks/${id}`);
      setTask(data);
    } catch (err) {
      console.error(err);
    }
  };

  const handleDelete = async () => {
    try {
      await axios.delete(`/api/tasks/${id}`);
      navigate('/tasks');
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div>
      {task && (
        <>
          <h1>{task.title}</h1>
          <p>{task.description}</p>
          <button onClick={handleDelete}>Delete</button>
        </>
      )}
    </div>
  );
};

export default TaskDetails;